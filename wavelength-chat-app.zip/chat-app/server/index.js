import express from "express";
import http from "http";
import cors from "cors";
import { Server } from "socket.io";
import { nanoid } from "nanoid";

const PORT = process.env.PORT || 4000;

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" },
});

// ---------- In-memory state ----------
// Channels: { id, name, topic, createdAt }
// Messages keyed by channel id, capped at MAX_HISTORY
// Users keyed by socket id: { id, name, color, channelId }

const MAX_HISTORY = 200;

const channels = new Map();
const messagesByChannel = new Map();
const usersBySocket = new Map();

const COLORS = [
  "#FFB74D", "#6EE7A8", "#7CC5FF", "#FF8A8A", "#C9A6FF", "#FFD166",
];

function seedChannels() {
  const defaults = [
    { name: "general", freq: "146.520", topic: "Main calling frequency — open chat" },
    { name: "random", freq: "147.435", topic: "Off-topic transmissions" },
    { name: "dev", freq: "223.500", topic: "Build talk, bugs, and deploys" },
  ];
  for (const d of defaults) {
    const id = nanoid(8);
    channels.set(id, { id, ...d, createdAt: Date.now() });
    messagesByChannel.set(id, []);
  }
}
seedChannels();

function publicChannels() {
  return [...channels.values()].map((c) => ({
    ...c,
    memberCount: [...usersBySocket.values()].filter((u) => u.channelId === c.id).length,
  }));
}

function publicUsers() {
  return [...usersBySocket.values()].map((u) => ({
    id: u.id,
    name: u.name,
    color: u.color,
    channelId: u.channelId,
  }));
}

function broadcastRoster() {
  io.emit("presence:roster", publicUsers());
  io.emit("channels:list", publicChannels());
}

// ---------- REST fallback (health check) ----------
app.get("/health", (_req, res) => {
  res.json({ ok: true, channels: channels.size, users: usersBySocket.size });
});

// ---------- Socket handling ----------
io.on("connection", (socket) => {
  socket.on("user:join", ({ name }, ack) => {
    const cleanName = String(name || "anon").slice(0, 24).trim() || "anon";
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];
    const firstChannel = [...channels.keys()][0];

    const user = { id: socket.id, name: cleanName, color, channelId: firstChannel };
    usersBySocket.set(socket.id, user);
    socket.join(firstChannel);

    ack?.({
      me: user,
      channels: publicChannels(),
      messages: messagesByChannel.get(firstChannel) || [],
    });

    io.to(firstChannel).emit("system:message", {
      id: nanoid(8),
      channelId: firstChannel,
      text: `${cleanName} signed on`,
      ts: Date.now(),
      system: true,
    });

    broadcastRoster();
  });

  socket.on("channel:switch", (channelId, ack) => {
    const user = usersBySocket.get(socket.id);
    if (!user || !channels.has(channelId)) return ack?.({ error: "invalid channel" });

    socket.leave(user.channelId);
    socket.join(channelId);
    user.channelId = channelId;

    ack?.({ messages: messagesByChannel.get(channelId) || [] });
    broadcastRoster();
  });

  socket.on("channel:create", ({ name, topic }, ack) => {
    const cleanName = String(name || "").trim().toLowerCase().replace(/\s+/g, "-").slice(0, 24);
    if (!cleanName) return ack?.({ error: "name required" });
    const exists = [...channels.values()].some((c) => c.name === cleanName);
    if (exists) return ack?.({ error: "channel already exists" });

    const id = nanoid(8);
    const freq = (100 + Math.random() * 300).toFixed(3);
    const channel = { id, name: cleanName, freq, topic: topic || "No topic set", createdAt: Date.now() };
    channels.set(id, channel);
    messagesByChannel.set(id, []);

    io.emit("channels:list", publicChannels());
    ack?.({ channel });
  });

  socket.on("message:send", ({ channelId, text }, ack) => {
    const user = usersBySocket.get(socket.id);
    if (!user || !channels.has(channelId)) return;
    const clean = String(text || "").slice(0, 2000).trim();
    if (!clean) return;

    const msg = {
      id: nanoid(10),
      channelId,
      text: clean,
      ts: Date.now(),
      user: { id: user.id, name: user.name, color: user.color },
    };

    const list = messagesByChannel.get(channelId) || [];
    list.push(msg);
    if (list.length > MAX_HISTORY) list.shift();
    messagesByChannel.set(channelId, list);

    io.to(channelId).emit("message:new", msg);
    ack?.({ ok: true });
  });

  socket.on("typing:start", (channelId) => {
    const user = usersBySocket.get(socket.id);
    if (!user) return;
    socket.to(channelId).emit("typing:update", { userId: user.id, name: user.name, typing: true });
  });

  socket.on("typing:stop", (channelId) => {
    const user = usersBySocket.get(socket.id);
    if (!user) return;
    socket.to(channelId).emit("typing:update", { userId: user.id, name: user.name, typing: false });
  });

  socket.on("disconnect", () => {
    const user = usersBySocket.get(socket.id);
    if (!user) return;
    usersBySocket.delete(socket.id);
    io.to(user.channelId).emit("system:message", {
      id: nanoid(8),
      channelId: user.channelId,
      text: `${user.name} signed off`,
      ts: Date.now(),
      system: true,
    });
    broadcastRoster();
  });
});

server.listen(PORT, () => {
  console.log(`Frequency chat server listening on :${PORT}`);
});
