# Wavelength — realtime chat

A real-time, multi-user chat app themed around ham-radio channels: rooms are
"frequencies," online users are "on air," and messages are "transmissions."

- **Server**: Node.js + Express + Socket.IO (in-memory, no database needed)
- **Client**: React + Vite, connected over WebSockets

## Features

- Multiple channels (frequencies) with live member counts, plus the ability to create new ones
- Real-time messaging, delivered instantly to everyone on the same channel
- Live "on air" roster of connected users with per-channel presence
- Typing indicators ("RAVEN-7 is transmitting…")
- System messages when someone signs on/off or switches channels
- Message history (last 200 per channel) replayed when you join or switch

## Running it locally

You'll need [Node.js](https://nodejs.org) 18+ installed.

**1. Start the server**

```bash
cd server
npm install
npm start
```

This runs the Socket.IO server on `http://localhost:4000`.

**2. Start the client** (in a second terminal)

```bash
cd client
npm install
npm run dev
```

This runs the Vite dev server, usually on `http://localhost:5173`. Open that
URL in a couple of browser tabs (or share it with a friend on your network) to
chat between them.

By default the client connects to `http://localhost:4000`. To point it at a
different server (e.g. when deploying), set `VITE_SERVER_URL` in a `.env`
file inside `client/`:

```
VITE_SERVER_URL=https://your-server.example.com
```

## Project structure

```
chat-app/
├── server/
│   ├── index.js        # Express + Socket.IO server, all chat logic
│   └── package.json
└── client/
    ├── src/
    │   ├── App.jsx              # top-level state & socket event wiring
    │   ├── socket.js            # socket.io-client instance
    │   ├── app.css               # design system (colors, type, layout)
    │   └── components/
    │       ├── JoinScreen.jsx    # callsign entry screen
    │       ├── TopBar.jsx        # active channel + connection status
    │       ├── ChannelDial.jsx   # sidebar channel switcher
    │       ├── TransmissionLog.jsx # message list
    │       ├── Composer.jsx      # message input + typing events
    │       └── RosterRail.jsx    # online users list
    └── package.json
```

## How it works

The server keeps everything in memory: a `Map` of channels, a `Map` of
message history per channel, and a `Map` of connected users keyed by socket
id. When a client connects it emits `user:join` with a chosen name; the
server assigns a color, drops them into the default channel, and acks back
their identity, the channel list, and recent history. From there, channel
switches, new messages, and typing state are just small socket events
broadcast to the right room.

Because state lives in memory, restarting the server clears all channels and
messages — this is meant as a learning project / starting point, not
production infrastructure. To make it persistent, swap the in-memory `Map`s
in `server/index.js` for a real database (Postgres, Redis, etc.).

## Ideas for extending it

- Persist channels/messages to a database
- Add authentication (replace the free-text callsign with real accounts)
- Direct messages between two users
- File/image sharing
- Message reactions or threads
