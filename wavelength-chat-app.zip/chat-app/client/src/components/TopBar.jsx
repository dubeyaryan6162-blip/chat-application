export default function TopBar({ channel, connected, meName }) {
  return (
    <header className="topbar">
      <div className="topbar-brand">FREQUENCY</div>

      <div className="topbar-readout" key={channel?.id}>
        <span className="topbar-freq">{channel?.freq ?? "---.---"}</span>
        <span className="topbar-mhz">MHz</span>
        <span className="topbar-channel-name">{channel ? `// ${channel.name}` : ""}</span>
      </div>

      <div className="topbar-status">
        <span className={"status-dot" + (connected ? " status-dot-on" : "")} />
        <span className="status-label">{connected ? "ON AIR" : "OFFLINE"}</span>
        {meName && <span className="topbar-me">{meName}</span>}
      </div>
    </header>
  );
}
