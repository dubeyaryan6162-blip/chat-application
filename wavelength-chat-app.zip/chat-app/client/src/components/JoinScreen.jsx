import { useState } from "react";

export default function JoinScreen({ onJoin, connecting, error }) {
  const [name, setName] = useState("");

  function handleSubmit(e) {
    e.preventDefault();
    if (!name.trim()) return;
    onJoin(name.trim());
  }

  return (
    <div className="join-screen">
      <div className="join-card">
        <div className="join-dial">
          <div className="join-dial-ring" />
          <div className="join-dial-needle" />
        </div>
        <div className="join-eyebrow">FREQUENCY // CONSOLE v1.0</div>
        <h1 className="join-title">Sign on to the air</h1>
        <p className="join-sub">
          Pick a callsign. You'll land on 146.520 — the main calling channel.
        </p>
        <form onSubmit={handleSubmit} className="join-form">
          <label className="join-label" htmlFor="callsign">
            CALLSIGN
          </label>
          <input
            id="callsign"
            autoFocus
            maxLength={24}
            placeholder="e.g. RAVEN-7"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className="join-input"
          />
          <button className="join-button" type="submit" disabled={connecting || !name.trim()}>
            {connecting ? "TUNING IN…" : "GO ON AIR"}
          </button>
          {error && <div className="join-error">{error}</div>}
        </form>
      </div>
    </div>
  );
}
