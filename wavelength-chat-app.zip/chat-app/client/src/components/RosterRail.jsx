export default function RosterRail({ users, activeChannelId, meId }) {
  const here = users.filter((u) => u.channelId === activeChannelId);
  const elsewhere = users.filter((u) => u.channelId !== activeChannelId);

  return (
    <aside className="roster">
      <div className="roster-heading">ON THIS FREQ · {here.length}</div>
      <div className="roster-list">
        {here.map((u) => (
          <RosterItem key={u.id} user={u} isMe={u.id === meId} />
        ))}
      </div>

      {elsewhere.length > 0 && (
        <>
          <div className="roster-heading roster-heading-dim">ELSEWHERE · {elsewhere.length}</div>
          <div className="roster-list">
            {elsewhere.map((u) => (
              <RosterItem key={u.id} user={u} isMe={u.id === meId} dim />
            ))}
          </div>
        </>
      )}
    </aside>
  );
}

function RosterItem({ user, isMe, dim }) {
  return (
    <div className={"roster-item" + (dim ? " roster-item-dim" : "")}>
      <span className="roster-bars" aria-hidden="true">
        <span style={{ animationDelay: "0ms" }} />
        <span style={{ animationDelay: "120ms" }} />
        <span style={{ animationDelay: "240ms" }} />
      </span>
      <span className="roster-name" style={{ color: user.color }}>
        {user.name}
        {isMe && <span className="roster-you"> (you)</span>}
      </span>
    </div>
  );
}
