import { useRef, useState } from "react";

export default function Composer({ onSend, onTypingStart, onTypingStop }) {
  const [text, setText] = useState("");
  const typingTimeout = useRef(null);

  function handleChange(e) {
    setText(e.target.value);
    onTypingStart();
    clearTimeout(typingTimeout.current);
    typingTimeout.current = setTimeout(() => {
      onTypingStop();
    }, 1200);
  }

  function handleSubmit(e) {
    e.preventDefault();
    const clean = text.trim();
    if (!clean) return;
    onSend(clean);
    setText("");
    clearTimeout(typingTimeout.current);
    onTypingStop();
  }

  return (
    <form className="composer" onSubmit={handleSubmit}>
      <span className="composer-mic">●</span>
      <input
        className="composer-input"
        placeholder="Transmit a message…"
        value={text}
        maxLength={2000}
        onChange={handleChange}
      />
      <button className="composer-send" type="submit" disabled={!text.trim()}>
        SEND
      </button>
    </form>
  );
}
