import { useState } from "react";

export default function ChannelDial({ channels, activeId, onSwitch, onCreate }) {
  const [creating, setCreating] = useState(false);
  const [draft, setDraft] = useState("");

  function submitCreate(e) {
    e.preventDefault();
    if (!draft.trim()) return;
    onCreate(draft.trim());
    setDraft("");
    setCreating(false);
  }

  return (
    <aside className="dial">
      <div className="dial-heading">DIAL</div>
      <div className="dial-list">
        {channels.map((c) => (
          <button
            key={c.id}
            className={"dial-item" + (c.id === activeId ? " dial-item-active" : "")}
            onClick={() => onSwitch(c.id)}
            title={c.topic}
          >
            <span className="dial-freq">{c.freq}</span>
            <span className="dial-name">{c.name}</span>
            <span className="dial-count">{c.memberCount}</span>
          </button>
        ))}
      </div>

      {creating ? (
        <form className="dial-create-form" onSubmit={submitCreate}>
          <input
            autoFocus
            className="dial-create-input"
            placeholder="new-channel"
            maxLength={24}
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onBlur={() => !draft && setCreating(false)}
          />
        </form>
      ) : (
        <button className="dial-create-btn" onClick={() => setCreating(true)}>
          + open new frequency
        </button>
      )}
    </aside>
  );
}
