import { useEffect, useRef } from "react";

function formatTime(ts) {
  const d = new Date(ts);
  return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" });
}

export default function TransmissionLog({ messages, meId, typingNames }) {
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth", block: "end" });
  }, [messages, typingNames]);

  return (
    <div className="log">
      {messages.length === 0 && (
        <div className="log-empty">
          No transmissions yet. Break the squelch — say something.
        </div>
      )}

      {messages.map((m) =>
        m.system ? (
          <div key={m.id} className="log-system">
            <span className="log-time">{formatTime(m.ts)}</span>
            <span>— {m.text} —</span>
          </div>
        ) : (
          <div key={m.id} className={"log-row" + (m.user.id === meId ? " log-row-me" : "")}>
            <span className="log-time">{formatTime(m.ts)}</span>
            <span className="log-name" style={{ color: m.user.color }}>
              {m.user.name}
            </span>
            <span className="log-text">{m.text}</span>
          </div>
        )
      )}

      {typingNames.length > 0 && (
        <div className="log-typing">
          <span className="typing-dots">
            <span />
            <span />
            <span />
          </span>
          {typingNames.join(", ")} {typingNames.length === 1 ? "is" : "are"} transmitting…
        </div>
      )}

      <div ref={endRef} />
    </div>
  );
}
