import { useCallback, useEffect, useRef, useState } from "react";
import { socket } from "./socket";
import JoinScreen from "./components/JoinScreen";
import TopBar from "./components/TopBar";
import ChannelDial from "./components/ChannelDial";
import TransmissionLog from "./components/TransmissionLog";
import Composer from "./components/Composer";
import RosterRail from "./components/RosterRail";
import "./app.css";

export default function App() {
  const [connecting, setConnecting] = useState(false);
  const [connected, setConnected] = useState(false);
  const [joinError, setJoinError] = useState(null);

  const [me, setMe] = useState(null);
  const [channels, setChannels] = useState([]);
  const [activeChannelId, setActiveChannelId] = useState(null);
  const [messages, setMessages] = useState([]);
  const [users, setUsers] = useState([]);
  const [typingByUser, setTypingByUser] = useState({}); // userId -> name

  const pendingName = useRef(null);
  const activeChannelIdRef = useRef(null);

  useEffect(() => {
    function onConnect() {
      setConnected(true);
      if (pendingName.current) {
        socket.emit("user:join", { name: pendingName.current }, (res) => {
          setConnecting(false);
          if (res?.error) {
            setJoinError(res.error);
            return;
          }
          setMe(res.me);
          setChannels(res.channels);
          setActiveChannelId(res.me.channelId);
          setMessages(res.messages);
        });
      }
    }

    function onDisconnect() {
      setConnected(false);
    }

    function onChannelsList(list) {
      setChannels(list);
    }

    function onPresenceRoster(list) {
      setUsers(list);
    }

    function onMessageNew(msg) {
      setMessages((prev) => (msg.channelId === activeChannelIdRef.current ? [...prev, msg] : prev));
    }

    function onSystemMessage(msg) {
      setMessages((prev) => (msg.channelId === activeChannelIdRef.current ? [...prev, msg] : prev));
    }

    function onTypingUpdate({ userId, name, typing }) {
      setTypingByUser((prev) => {
        const next = { ...prev };
        if (typing) next[userId] = name;
        else delete next[userId];
        return next;
      });
    }

    socket.on("connect", onConnect);
    socket.on("disconnect", onDisconnect);
    socket.on("channels:list", onChannelsList);
    socket.on("presence:roster", onPresenceRoster);
    socket.on("message:new", onMessageNew);
    socket.on("system:message", onSystemMessage);
    socket.on("typing:update", onTypingUpdate);

    return () => {
      socket.off("connect", onConnect);
      socket.off("disconnect", onDisconnect);
      socket.off("channels:list", onChannelsList);
      socket.off("presence:roster", onPresenceRoster);
      socket.off("message:new", onMessageNew);
      socket.off("system:message", onSystemMessage);
      socket.off("typing:update", onTypingUpdate);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // keep the ref in sync so socket callbacks (closed over on mount) read the latest value
  useEffect(() => {
    activeChannelIdRef.current = activeChannelId;
  }, [activeChannelId]);

  function handleJoin(name) {
    setConnecting(true);
    setJoinError(null);
    pendingName.current = name;
    socket.connect();
  }

  function handleSwitchChannel(channelId) {
    if (channelId === activeChannelId) return;
    socket.emit("channel:switch", channelId, (res) => {
      if (res?.error) return;
      setActiveChannelId(channelId);
      setMessages(res.messages);
      setTypingByUser({});
    });
  }

  function handleCreateChannel(name) {
    socket.emit("channel:create", { name }, (res) => {
      if (res?.channel) {
        handleSwitchChannel(res.channel.id);
      }
    });
  }

  const handleSend = useCallback(
    (text) => {
      if (!activeChannelId) return;
      socket.emit("message:send", { channelId: activeChannelId, text });
    },
    [activeChannelId]
  );

  const handleTypingStart = useCallback(() => {
    if (activeChannelId) socket.emit("typing:start", activeChannelId);
  }, [activeChannelId]);

  const handleTypingStop = useCallback(() => {
    if (activeChannelId) socket.emit("typing:stop", activeChannelId);
  }, [activeChannelId]);

  if (!me) {
    return (
      <>
        <JoinScreen onJoin={handleJoin} connecting={connecting} error={joinError} />
        <div className="grain" />
        <div className="scanlines" />
      </>
    );
  }

  const activeChannel = channels.find((c) => c.id === activeChannelId) || null;
  const typingNames = Object.values(typingByUser);

  return (
    <div className="console">
      <TopBar channel={activeChannel} connected={connected} meName={me.name} />
      <div className="console-body">
        <ChannelDial
          channels={channels}
          activeId={activeChannelId}
          onSwitch={handleSwitchChannel}
          onCreate={handleCreateChannel}
        />
        <main className="console-main">
          <TransmissionLog messages={messages} meId={me.id} typingNames={typingNames} />
          <Composer onSend={handleSend} onTypingStart={handleTypingStart} onTypingStop={handleTypingStop} />
        </main>
        <RosterRail users={users} activeChannelId={activeChannelId} meId={me.id} />
      </div>
      <div className="grain" />
      <div className="scanlines" />
    </div>
  );
}
